package com.termux.terminal;

import android.util.Log;

public final class EmulatorDebug {

    /** The tag to use with {@link Log}. */
    public static final String LOG_TAG = "termux";

}
