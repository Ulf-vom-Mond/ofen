---
name: Feature request
about: Suggest a new feature in termux-app

---

**Feature description**
Describe the feature and why you want it.

**Reference implementation**
Does another app/terminal emulator have this feature?
Provide links to more background information
